# DAY 1 — Project Scaffold, Python Environment, and Your First LLM Call

**Difficulty:** Beginner-friendly, foundational
**Estimated Time:** 2.5–3.5 hours

---

## 1. Learning Objectives

By the end of today you will:
- Have a real, versioned repo: `ai-crm-platform/`
- Understand *why* virtual environments, `.env` files, and clean project layout matter in production AI systems (not just "best practice" — actual failure modes they prevent)
- Make your first programmatic call to an LLM (OpenAI or Gemini) and get a response back in Python
- Understand the shape of a Chat Model API call (messages, roles, tokens) before LangChain ever wraps it for you — because you should never treat a framework as a black box

---

## 2. Theory Topics
- Virtual environments (`venv`) and dependency isolation
- `.env` files and secrets management
- Project folder architecture for scalable AI apps
- Git basics: init, `.gitignore`, first commit
- The anatomy of an LLM API request/response (roles: system/user/assistant, tokens, temperature)
- Sync vs async call basics (why this matters later for FastAPI)

---

## 3. Concept Explanation (full 15-point breakdown)

### 3.1 What is it?
A **virtual environment** is an isolated Python installation just for one project — its own copy of installed packages, separate from your system Python and from every other project on your machine.

An **LLM API call** is simply an HTTP POST request to a provider's server (OpenAI, Google, Anthropic) containing a list of messages; the server runs the model and returns generated text as JSON.

### 3.2 Why do we need it?
Without isolation, two projects needing different versions of the same library (e.g. `langchain==0.1` vs `langchain==0.3`) will break each other. Without understanding the raw API call, you'll be lost the moment LangChain throws an error inside its abstraction — you won't know if the bug is in your prompt, your key, or the network.

### 3.3 Problem before this concept existed
Early Python devs installed everything globally (`pip install X`). One day, upgrading a package for Project B silently broke Project A because they shared the same global `site-packages`. This is called **dependency hell**. `venv` (and later `poetry`/`uv`) solved this by giving every project its own sandbox.

For LLM calls: before SDKs existed, people manually built HTTP requests with `requests` — that's actually still worth knowing, because it's exactly what happens *underneath* `openai.ChatCompletion.create()` or LangChain's `ChatOpenAI`.

### 3.4 How it works internally
- `python -m venv .venv` creates a folder with a copied/symlinked Python interpreter + an empty `Lib/site-packages`.
- Activating it rewires your shell's `PATH` so `python` and `pip` point inside `.venv/` first.
- An LLM API call: your Python client serializes your messages list to JSON → sends HTTPS POST to `https://api.openai.com/v1/chat/completions` (or Gemini's equivalent) with your API key in the `Authorization` header → the provider's server tokenizes your input, runs it through the model, streams/returns tokens back → your client deserializes the JSON response.

### 3.5 Architecture (today's scope)
```
ai-crm-platform/
├── .venv/                  (not committed)
├── .env                    (not committed — secrets)
├── .gitignore
├── requirements.txt
├── README.md
└── app/
    ├── __init__.py
    └── core/
        └── llm_client.py   (today's code lives here)
```

### 3.6 Real-world example
Every production company (Stripe, Notion, Netflix) isolates environments per service using containers (Docker) — `venv` is the beginner version of the same idea: **don't let dependencies leak across boundaries.**

### 3.7 CRM example
Later, your CRM will have an `api` service, a `worker` service (Celery), and a `dashboard` service — each with different dependencies. If you don't learn isolation now with `venv`, you will not understand why Docker Compose gives each of these its own container later.

### 3.8 Startup example
Startups that skip this die by "works on my machine" bugs — a teammate's laptop has different package versions, deploy breaks in production, nobody knows why. Clean environment discipline from Day 1 is a founder-level habit, not just a coding one.

### 3.9 Agentic AI example
Every agent you build later ultimately reduces to: **a Chat Model call, with a system prompt describing its role, wrapped in a loop.** Today's raw API call *is* that atomic unit. An "agent" is just this call repeated with tools and memory added — nothing magical.

### 3.10 Interview answer (how to say this in an interview)
> "I use `venv` (or `poetry`/`uv` in production) to isolate dependencies per project, avoiding version conflicts across services. For LLM integration, I understand the underlying REST contract — a messages array with roles, sent over HTTPS — so that when I use a framework like LangChain, I can debug through the abstraction rather than being blocked by it."

### 3.11 Python code (raw, no LangChain yet — this is intentional)
```python
# app/core/llm_client.py
import os
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()  # reads .env into environment variables

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def ask_llm(user_message: str) -> str:
    """The most basic possible LLM call — the atomic unit everything else builds on."""
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "You are a helpful CRM assistant."},
            {"role": "user", "content": user_message},
        ],
        temperature=0.3,
    )
    return response.choices[0].message.content

if __name__ == "__main__":
    print(ask_llm("Say hello to a new CRM user named Aditya."))
```

### 3.12 LangChain code (preview only — we build this properly on Day 7)
```python
# preview — do NOT implement fully today, just read it
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(model="gpt-4o-mini", temperature=0.3)
response = llm.invoke("Say hello to a new CRM user named Aditya.")
print(response.content)
```
Notice: LangChain's `.invoke()` is doing *exactly* what your raw `ask_llm()` function does — just standardized across 20+ providers. That standardization is the entire value proposition of LangChain's model layer.

### 3.13 Best practices
- Never hardcode API keys — always `.env` + `.gitignore`
- Pin dependency versions in `requirements.txt`
- One virtual environment per project, always
- Commit early, commit often, with meaningful messages

### 3.14 Common mistakes
- Committing `.env` to Git (leaks API keys — very common beginner incident)
- Installing packages globally, then wondering why nothing matches the tutorial
- Not pinning versions, so `pip install` today vs next month gives different behavior
- Copy-pasting an API key into code "just for now" and forgetting to remove it

### 3.15 Production considerations
- In real deployments, secrets come from a secret manager (AWS Secrets Manager, GCP Secret Manager, Doppler) — not flat `.env` files. We'll get there in Week 4.
- Rate limits and retries matter — production LLM clients need exponential backoff (we'll add this when we build the real `ChatModel` service on Day 3).

---

## 4. Real-World Analogy
A virtual environment is like giving every guest at a hotel their own room instead of one shared apartment — nobody's stuff gets mixed up, and evicting one guest (deleting one `venv`) doesn't affect anyone else.

An LLM API call is like sending a letter to a translator: you write your message (user content) plus a note about how they should behave (system prompt), seal it in an envelope (JSON), mail it (HTTPS POST), and they mail back a reply.

---

## 5. Interview Questions
1. What problem does a virtual environment solve that global installs don't?
2. What's inside a `messages` array in a Chat Completion API call, and what does each role mean?
3. Why should `.env` never be committed to Git — what's the actual risk?
4. What is `temperature` doing at the API level?
5. If `pip install` works on your machine but fails in CI, what's your first debugging step?

---

## 6. Coding Exercise
Write a script `exercise_day1.py` that:
1. Loads your API key from `.env`
2. Sends **two** different `system` prompts (one "formal CRM assistant", one "casual friendly assistant") with the same user question
3. Prints both responses side-by-side to observe how the system prompt changes tone

## 7. Mini Assignment
Extend `ask_llm()` to accept a `system_prompt` parameter (instead of hardcoding it), with a sensible default. This small refactor is your first step toward configurable agents.

## 8. Project Integration
This is the literal foundation of `app/core/llm_client.py`, which every future agent (Chat Assistant, Support Agent, Sales Agent, Analytics Agent) will eventually import and extend. Nothing here is throwaway.

## 9. Folder Structure Changes
```
+ ai-crm-platform/
+ ├── .venv/
+ ├── .env
+ ├── .gitignore
+ ├── requirements.txt
+ ├── README.md
+ └── app/
+     ├── __init__.py
+     └── core/
+         ├── __init__.py
+         └── llm_client.py
```

## 10. Git Commit Message
```
git init
git add .
git commit -m "chore: initial project scaffold + first raw LLM API call"
```

## 11. Common Mistakes (recap, project-specific)
- Forgetting `python-dotenv` in `requirements.txt` → `load_dotenv()` silently does nothing
- Using `gpt-4o-mini` vs `gpt-4o` inconsistently across files (pin the model name in one config place — we fix this properly on Day 3)

## 12. Revision Checklist
- [ ] I can explain why `venv` exists in one sentence
- [ ] I can name the 3 roles in a chat messages array
- [ ] I have a working `.env` + `.gitignore` that excludes it
- [ ] I successfully printed a real LLM response from my own script
- [ ] I understand that LangChain's `.invoke()` wraps the same HTTP call I made manually

## 13. Expected Output
```
$ python app/core/llm_client.py
Hello Aditya! Welcome to our CRM platform — we're excited to have you on board...
```

## 14. Difficulty Level
⭐☆☆☆☆ (1/5) — pure setup, but foundational. Don't skip understanding *why*, even though the code is simple.

---

### Next
Reply **"Day 2"** (or just "next") when ready — we move to OOP for AI systems and start designing the `BaseAgent` class hierarchy your whole platform will build on.
